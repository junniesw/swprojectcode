from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from datetime import datetime
from functools import wraps

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['UPLOAD_FOLDER'] = 'static/uploads/'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['SQLALCHEMY_BINDS'] = {
    'photos': 'sqlite:///photos.db'
}
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_size': 1,
    'pool_timeout': 30,
    'pool_recycle': 90,
    'pool_pre_ping': True,
    'connect_args': {'check_same_thread': False}
}
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# 모델 정의
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)

class Photo(db.Model):
    __bind_key__ = 'photos'
    id = db.Column(db.Integer, primary_key=True)
    image_file = db.Column(db.String(20), nullable=False)
    description = db.Column(db.String(500), nullable=True)
    tags = db.Column(db.String(200), nullable=True)
    user_id = db.Column(db.Integer, nullable=False)

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content = db.Column(db.String(500), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    sender = db.relationship('User', foreign_keys=[sender_id], backref='sent_messages')
    receiver = db.relationship('User', foreign_keys=[receiver_id], backref='received_messages')

# 데이터베이스 초기화
with app.app_context():
    db.create_all()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('signin'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/signin', methods=['GET', 'POST'])
def signin():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            return redirect(url_for('welcome'))
        else:
            flash('Invalid email or password', 'danger')
    return render_template('signin.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        user = User(username=username, email=email, password=hashed_password)
        db.session.add(user)
        try:
            db.session.commit()
            flash('Sign up successful', 'success')
            return redirect(url_for('signin'))
        except IntegrityError:
            db.session.rollback()
            flash('Email already exists. Please use a different email.', 'danger')
    return render_template('signup.html')

@app.route('/welcome')
@login_required
def welcome():
    user_id = session['user_id']
    current_user = User.query.get(user_id)
    photos = Photo.query.all()
    users = User.query.all()
    photo_users = [(photo, User.query.get(photo.user_id)) for photo in photos]
    return render_template('welcome.html', user=current_user, photos=photos, users=users, photo_users=photo_users, current_user=current_user)

@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    if request.method == 'POST':
        if 'photo' not in request.files:
            flash('No file part', 'danger')
            return redirect(request.url)
        file = request.files['photo']
        if file.filename == '':
            flash('No selected file', 'danger')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            if not os.path.exists(app.config['UPLOAD_FOLDER']):
                os.makedirs(app.config['UPLOAD_FOLDER'])
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            description = request.form.get('description')
            tags = request.form.get('tags')
            photo = Photo(image_file=filename, description=description, tags=tags, user_id=session['user_id'])
            db.session.add(photo)
            db.session.commit()
            flash('Photo uploaded successfully!', 'success')
            return redirect(url_for('welcome'))
    return render_template('upload.html')

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'png', 'jpg', 'jpeg', 'gif'}

@app.route('/logout', methods=['POST'])
def logout():
    session.pop('user_id', None)
    flash('Logged out successfully!', 'success')
    return redirect(url_for('signin'))

@app.route('/user_list')
def user_list():
    users = User.query.all()
    user_list = [{'username': user.username, 'email': user.email} for user in users]
    return jsonify(user_list)

@app.route('/delete_photo/<int:photo_id>', methods=['POST'])
@login_required
def delete_photo(photo_id):
    photo = Photo.query.get(photo_id)
    if photo.user_id == session['user_id']:
        db.session.delete(photo)
        db.session.commit()
        flash('Photo deleted successfully!', 'success')
    else:
        flash('You are not authorized to delete this photo.', 'danger')
    return redirect(url_for('welcome'))

@app.route('/search', methods=['POST'])
@login_required
def search():
    keyword = request.form.get('keyword')
    return redirect(url_for('search_results', keyword=keyword))

@app.route('/search/<keyword>', endpoint='search_results')
@login_required
def search_results(keyword):
    user_id = session['user_id']
    user = User.query.get(user_id)
    photos = Photo.query.filter(Photo.tags.contains(keyword)).all()
    users = User.query.all()

    # 각 Photo 객체에 대응하는 User 객체를 가져와서 추가
    photo_users = []
    for photo in photos:
        photo_user = User.query.get(photo.user_id)
        photo_users.append((photo, photo_user))

    return render_template('search_results.html', user=user, photo_users=photo_users, users=users, keyword=keyword)

@app.route('/edit_photo/<int:photo_id>', methods=['GET', 'POST'])
@login_required
def edit_photo(photo_id):
    photo = Photo.query.get(photo_id)
    if photo.user_id == session['user_id']:
        if request.method == 'POST':
            photo.description = request.form.get('description')
            photo.tags = request.form.get('tags')
            db.session.commit()
            flash('Photo updated successfully!', 'success')
            return redirect(url_for('welcome'))
        return render_template('edit_photo.html', photo=photo)
    else:
        flash('You are not authorized to edit this photo.', 'danger')
        return redirect(url_for('welcome'))

@app.route('/send_message', methods=['POST'])
@login_required
def send_message():
    sender_id = session['user_id']
    receiver_username = request.json.get('receiver_username')
    content = request.json.get('content')
    
    receiver = User.query.filter_by(username=receiver_username).first()
    if receiver:
        message = Message(sender_id=sender_id, receiver_id=receiver.id, content=content)
        db.session.add(message)
        db.session.commit()
        return jsonify({"status": "success", "message": "Message sent successfully!"})
    return jsonify({"status": "error", "message": "User not found."})

@app.route('/delete_message/<int:message_id>', methods=['DELETE'])
@login_required
def delete_message(message_id):
    message = Message.query.get(message_id)
    if message and message.sender_id == session['user_id']:
        db.session.delete(message)
        db.session.commit()
        return jsonify({"status": "success", "message": "Message deleted successfully!"})
    return jsonify({"status": "error", "message": "Message not found or you are not authorized to delete it."})

@app.route('/get_messages/<username>', methods=['GET'])
@login_required
def get_messages(username):
    user = User.query.filter_by(username=username).first()
    if user:
        messages = Message.query.filter(
            (Message.sender_id == session['user_id']) & (Message.receiver_id == user.id) |
            (Message.sender_id == user.id) & (Message.receiver_id == session['user_id'])
        ).all()
        message_list = [{
            'id': msg.id,
            'sender': User.query.get(msg.sender_id).username,
            'content': msg.content
        } for msg in messages]
        return jsonify(message_list)
    return jsonify([])

@app.route('/get_conversations', methods=['GET'])
@login_required
def get_conversations():
    user_id = session['user_id']
    sent_messages = Message.query.filter_by(sender_id=user_id).all()
    received_messages = Message.query.filter_by(receiver_id=user_id).all()
    
    conversations = set()
    for msg in sent_messages:
        conversations.add(User.query.get(msg.receiver_id).username)
    for msg in received_messages:
        conversations.add(User.query.get(msg.sender_id).username)
    
    return jsonify(list(conversations))




if __name__ == '__main__':
    app.run(debug=True)
