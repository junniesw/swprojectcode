from routes import app, db

# 데이터베이스를 초기화하고 테이블 생성
with app.app_context():
    db.create_all()
